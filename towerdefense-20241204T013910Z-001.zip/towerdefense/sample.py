import pygame
import random

# Pygame 초기화
pygame.init()

# 화면 크기 설정
screen_width = 1210#게임 화면 (0<x<800) , ui (800<x<1200)
screen_height = 800
screen = pygame.display.set_mode((screen_width, screen_height))
pygame.display.set_caption('tower_defense')
background = pygame.image.load('background.png')
ganghwa = pygame.image.load('ganghwa.png')
buildtower = pygame.image.load('tower.png')
setting = pygame.image.load('setting.png')

def choosefont(size):
    font = pygame.font.Font(None, size)
    return font

WHITE = (255, 255, 255)
RED = (255, 0, 0)
GREEN = (0, 255, 0)

# 타워 클래스
class Tower:
    def __init__(self, x, y, type):
        self.x = x
        self.y = y
        self.type = type

        if type == 'common':
            self.damage = 80
            self.initial_damage = 80
            self.range = 110
            self.speed = 300
            self.color = GREEN
            self.cost = 500
        
        elif type == 'rare':
            self.damage = 240
            self.initial_damage = 240
            self.range = 170
            self.speed = 400
            self.color = (0,128,128)
            self.cost = 2000

        elif type == 'epic':
            self.damage = 50
            self.initial_damage = 50
            self.range = 230
            self.speed = 100
            self.color = (0,0,0)
            self.cost = 5000

        #---------------------------------위쪽이 기본타워,아래쪽이 특수타워
        elif type == 'slow':#슬로우(데미지 0)
            self.range = 200
            self.color = (128,0,0)
            self.cost = 4000
            self.slownum = 0.6
            self.speed = 0
            self.damage = 0
        elif type == 'percent':#적 현재 체력의 40퍼센트 데미지, 범위에 있는 적 중 가장 hp가 많은적 공격, 최소 공격력 100
            self.perdamage = 0.65
            self.range = 150
            self.speed = 300
            self.color = (0,128,0)
            self.mindamage = 100
            self.maxdamage = 2000
            self.initial_maxdamage = 1000
            self.cost = 6000

        self.lastattack = pygame.time.get_ticks()
        
    def draw(self,player):#타워 생성
        if player.rangecircle:
            pygame.draw.circle(screen, self.color, (self.x, self.y), self.range, 1)
        pygame.draw.rect(screen, self.color, (self.x-10, self.y-10, 20, 20))

    def attack(self, enemies):#attack_speed에 맞춰서 공격
        if self.type == 'slow':
            for enemy in enemies:
                if self.is_in_range(enemy):
                    pygame.draw.line(screen, self.color, (self.x,self.y), (enemy.x+10,enemy.y+10), 4)
                    if self not in enemy.slow_tower:
                        enemy.slow_tower.append(self)
                else:
                    if self in enemy.slow_tower:
                        enemy.slow_tower.remove(self)
                    
                if enemy.slow_tower:
                    enemy.speed = enemy.initial_speed*self.slownum
                else:
                    enemy.speed = enemy.initial_speed
        elif self.type == 'percent':
            target = False
            target_hp = 0
            for enemy in enemies:
                if enemy.health > target_hp and self.is_in_range(enemy):
                    target = enemy
                    target_hp = enemy.health
            if target and pygame.time.get_ticks()-self.lastattack >= self.speed:
                if target.health <= self.mindamage:
                    target.health -= self.mindamage
                elif target.health*0.4 >= self.maxdamage:
                    target.health -= self.maxdamage
                else:
                    target.health *= self.perdamage
                pygame.draw.line(screen, self.color, (self.x,self.y), (target.x+10,target.y+10), 4)
                self.lastattack = pygame.time.get_ticks()
        
        else:
            for enemy in enemies:
                if pygame.time.get_ticks()-self.lastattack >= self.speed and self.is_in_range(enemy):
                    enemy.health -= self.damage
                    pygame.draw.line(screen, self.color, (self.x,self.y), (enemy.x+10,enemy.y+10), 4)
                    self.lastattack = pygame.time.get_ticks()

    def is_in_range(self, enemy):#공격 범위에 적이 들어왔는가?
        distance = ((self.x - enemy.x) ** 2 + (self.y - enemy.y) ** 2) ** 0.5
        return distance <= self.range

    def is_same_coord(self,towers):
        for tower in towers:
            if self.x == tower.x and self.y == tower.y:
                return False
        return True



# 적 클래스
class Enemy:
    num = 0
    bosscount = 0
    def __init__(self, x, y, health,speed ,coin,tag):
        self.x = x
        self.y = y
        self.health = health
        self.color = RED
        self.speed = speed
        self.initial_speed = speed
        self.coin = coin
        self.arrive = False
        self.initial_hp = health
        self.tag = tag
        self.slow_tower = []

    def move(self):#몹이 움직이는 거 설정
        if (self.x % 200) <= 5 and self.x >= 150:
            if (self.x//200)%2 ==1:
                self.y += self.speed
                if self.y >= 500:
                    self.x +=self.speed
            else:
                self.y -= self.speed
                if self.y <= 100:
                    self.x +=self.speed
        else:
            self.x += self.speed
    def draw(self):#적 생성
        if self.tag == 'common':
            pygame.draw.rect(screen, self.color, (self.x, self.y, 20, 20))
            pygame.draw.rect(screen, (0,0,0), (self.x, self.y, 20, 20),1)
        elif self.tag == 'boss':
            pygame.draw.rect(screen, self.color, (self.x, self.y, 25, 25))
            pygame.draw.rect(screen, (0,0,0), (self.x, self.y, 26, 26),5)

    def hpcolor(self):#몹 체력 70퍼 남으면 주황색, 40퍼 남으면 노랑색으로 변경
        if self.health <= 0.4*self.initial_hp:
            self.color = (255,255,0)
        elif self.health <= 0.7*self.initial_hp:
            self.color = (255,165,0)
    
    def isarrive(self):#적이 오른쪽 끝에 도착했는지 확인
        if self.x > 780:#창이 800*800이라 x가 800이 넘으면 도착으로 판정
            self.health = -10000#창 넘어간 적 삭제 위해 체력 0으로 설정
            self.arrive = True
        return self.x>780

    def hpbar(self):
        hplength = 20*self.health/self.initial_hp
        pygame.draw.rect(screen, (0,0,0), (self.x-1, self.y+15, 22, 7))
        pygame.draw.rect(screen, RED, (self.x, self.y+16, hplength, 5))

    @classmethod
    def numplus(cls):#적이 소환된 횟수 계산
        cls.num += 1

class Player:
    c_level,r_level,e_level = 1,1,1
    c_cost, r_cost, e_cost = 1000,2000,3000
    
    def __init__(self,hp,money):
        self.hp = hp
        self.initialhp = hp
        self.money = money
        self.score = 0
        self.rangecircle = True

    def hpminus(self,enemy):
        if enemy.isarrive():#적이 도착했을때 hp -1 보스는 -2
            if enemy.tag == 'boss':
                self.hp -= 2
            else:
                self.hp -= 1
            return self.hp

    def usecoin(self,usemoney):#하나 설치할때 돈 소모
        try:
            if usemoney>self.money:
                raise NoMoney
        except NoMoney as e:
            return e
        else:
            self.money -= usemoney
            return ''

    def addmoney(self,enemy):#적 잡을때 마다 돈 추가
        if enemy.health <=0:
            self.money += enemy.coin
        if self.money >= 100000:
            self.money = 100000

    def circle_setting(self):
        self.rangecircle = not self.rangecircle

    def UI(self,tower_type):
        if tower_type == 'common':
            pygame.draw.rect(screen, (255,255,100), (816,5, 126, 194),5)
            pygame.draw.rect(screen, GREEN, (1121,230,40,40))
            leveltext = choosefont(30).render('level '+ str(Player.c_level),True,(0,0,0))
            upgradecost_text = choosefont(25).render(str(Player.c_cost)+'$',True,(0,0,0))
        elif tower_type == 'rare':
            pygame.draw.rect(screen, (255,255,100), (947,5, 126, 194),5)
            pygame.draw.rect(screen, (0,128,128), (1121,230,40,40))
            leveltext = choosefont(30).render('level '+ str(Player.r_level),True,(0,0,0))
            upgradecost_text = choosefont(25).render(str(Player.r_cost)+'$',True,(0,0,0))
        elif tower_type == 'epic':
            pygame.draw.rect(screen, (255,255,100), (1078,5, 126, 194),5)
            pygame.draw.rect(screen, (0,0,0), (1121,230,40,40))
            leveltext = choosefont(30).render('level '+ str(Player.e_level),True,(0,0,0))
            upgradecost_text = choosefont(25).render(str(Player.e_cost)+'$',True,(0,0,0))
        elif tower_type == 'slow':
            pygame.draw.rect(screen, (255,255,100), (816,206, 126, 194),5)
        elif tower_type == 'percent':
            pygame.draw.rect(screen, (255,255,100), (947,206, 126, 194),5)

        if tower_type in ('common','rare','epic'):
            typetext = choosefont(30).render(tower_type,True,(0,0,0))
            screen.blit(typetext,((126-typetext.get_width())/2+1078,281))
            screen.blit(leveltext,((126-leveltext.get_width())/2+1078,301))
            screen.blit(upgradecost_text,((126-upgradecost_text.get_width())/2+1078,329))

    def levelup(self,tower_type):
        try:
            if tower_type in ['slow','percent']:
                raise SpTowerUpgrade
        except SpTowerUpgrade as e:
            return e
        else:
            if tower_type == 'common' and self.money >= Player.c_cost:
                Player.c_level += 1
                self.usecoin(Player.c_cost)
                Player.c_cost = int(Player.c_cost*1.5)
            elif tower_type == 'rare' and self.money >= Player.r_cost:
                Player.r_level += 1
                self.usecoin(Player.r_cost)
                Player.r_cost = int(Player.r_cost*1.5)
            elif tower_type == 'epic' and self.money >= Player.e_cost:
                Player.e_level += 1
                self.usecoin(Player.e_cost)
                Player.e_cost = int(Player.e_cost*1.5)
            return ''

class NoMoney(Exception):
    def __init__(self):
        super().__init__('not enough money')
class SpTowerUpgrade(Exception):
    def __init__(self):
        super().__init__('This tower cannot be upgraded')

            
# 게임 루프
def game_loop():
    clock = pygame.time.Clock()
    running = True
    game_over = False
    infotowers = [Tower(2000,0,'common'),Tower(2000,0,'rare'),Tower(2000,0,'epic'),Tower(2000,0,'slow'),Tower(2000,0,'percent')]#타워 리스트(타워 정보띄우기용 타워)]
    towers = []#타워 리스트
    enemies = []#적 리스트
    buttons = []
    NoMoneytext = ''
    upgrademessage = ''
    Enemy.bosscount = 0
    Enemy.num = 0
    player = Player(10, 10000)
    best_score = 0
    ganghwa_rect = pygame.Rect(ganghwa.get_rect(topleft=(1091, 355)))
    lastenhancetime = 0
    setting_rect = pygame.Rect(setting.get_rect(topleft=(740, 740)))
    NoMoneytime = 0
    for i in range(1,4):
        buttons.append((125,150*i-5))
        buttons.append((265,150*i-5))
        buttons.append((325,150*i-5))
        buttons.append((465,150*i-5))
        buttons.append((525,150*i-5))
        buttons.append((665,150*i-5))

    tower_type = 'common'#타워의 기본 타입 = common

    

    while running:
        screen.blit(background,(0,0))
        screen.blit(ganghwa,(1088,355))
        screen.blit(setting,(740,740))
        ganghwatext = choosefont(30).render('upgrade',True,(0,0,0))
        screen.blit(ganghwatext,((126-ganghwatext.get_width())/2+1078,362))
        for button in buttons:
            screen.blit(buildtower,(button))
        
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                for button in buttons:
                    button_rect = pygame.Rect(button[0], button[1], buildtower.get_width(), buildtower.get_height())
                    if button_rect.collidepoint(event.pos):
                        new_tower = Tower(button[0]+15, button[1]+15, tower_type)
                        if new_tower.is_same_coord(towers):
                            NoMoneytime = pygame.time.get_ticks()
                            NoMoneytext = player.usecoin(new_tower.cost)
                            if NoMoneytext == '':
                                towers.append(new_tower)

                if setting_rect.collidepoint(event.pos):
                    player.circle_setting()

            elif event.type == pygame.MOUSEBUTTONDOWN and event.button == 3:
                for button in buttons:
                    button_rect = pygame.Rect(button[0], button[1], buildtower.get_width(), buildtower.get_height())
                    for tower in towers:
                        if tower.x == button[0]+15 and tower.y == button[1]+15 and button_rect.collidepoint(event.pos):
                            towers.remove(tower)
        


        if pygame.time.get_ticks() - NoMoneytime < 2000:
            screen.blit(choosefont(30).render(f'{NoMoneytext}',True,RED),(20,700))

        if player.hp == 0:
            game_over = True

        if player.score >= best_score:
            best_score = player.score
        
        pygame.draw.rect(screen, GREEN, (859,30, 40, 40))
        pygame.draw.rect(screen, (0,128,128), (990, 30, 40, 40))
        pygame.draw.rect(screen, (0,0,0), (1121, 30, 40, 40))
        pygame.draw.rect(screen, (128,0,0), (859, 230, 40, 40))
        pygame.draw.rect(screen, (0,128,0), (990, 230, 40, 40))

        hptext = choosefont(40).render('HP : '+str(player.hp),True,(0,0,0))
        screen.blit(hptext,(830,420))

        moneytext = choosefont(35).render('COIN : '+str(player.money)+'$',True,(0,0,0))
        screen.blit(moneytext,(830,590))

        scoretext = choosefont(35).render('SCORE : ' +str(player.score),True,(0,0,0))
        screen.blit(scoretext,(830,470))

        bestscoretext = choosefont(35).render('BEST SCORE : ' +str(best_score),True,(0,0,0))
        screen.blit(bestscoretext,(830,510))

        if player.rangecircle:
            settingtext = choosefont(25).render('ON',True,(0,0,0))
        else:
            settingtext = choosefont(25).render('OFF',True,(0,0,0))
        screen.blit(settingtext,(740+(50-settingtext.get_width())/2,740+(50-settingtext.get_height())/2))


        for tower in towers:
            if tower.type == 'common':
                tower.damage = tower.initial_damage*1.2**(Player.c_level-1)
            elif tower.type == 'rare':
                tower.damage = tower.initial_damage*1.2**(Player.r_level-1)
            elif tower.type == 'epic':
                tower.damage = tower.initial_damage*1.2**(Player.e_level-1)

        for tower in infotowers:
            if tower.type == 'common':
                tower.damage = tower.initial_damage*1.2**(Player.c_level-1)
            elif tower.type == 'rare':
                tower.damage = tower.initial_damage*1.2**(Player.r_level-1)
            elif tower.type == 'epic':
                tower.damage = tower.initial_damage*1.2**(Player.e_level-1)

        if pygame.time.get_ticks() - lastenhancetime < 2000:
            screen.blit(choosefont(30).render(f'{upgrademessage}',True,RED),(20,730))

        if event.type == pygame.MOUSEBUTTONDOWN and ganghwa_rect.collidepoint(event.pos) and pygame.time.get_ticks()-lastenhancetime>500:
            upgrademessage = player.levelup(tower_type)
            lastenhancetime = pygame.time.get_ticks()

        key = pygame.key.get_pressed()#key = 누른 키 저장
        if key[pygame.K_1]:#1,2,3,4,5 구분하여 설치할 타워의 type 변환
            tower_type = 'common'
        elif key[pygame.K_2]:
            tower_type = 'rare'
        elif key[pygame.K_3]:
            tower_type = 'epic'
        elif key[pygame.K_4]:
            tower_type = 'slow'
        elif key[pygame.K_5]:
            tower_type = 'percent'
        
        player.UI(tower_type)

        for tower in infotowers:
            if tower.type == 'common':
                x,y = 816,80
                damagetext = choosefont(25).render('{:.1f} damage'.format(tower.damage),True,(0,0,0))
                speedtext = choosefont(25).render('{}s'.format(tower.speed/1000),True,(0,0,0))
                costtext = choosefont(25).render('{}$'.format(tower.cost),True,(0,0,0))
            elif tower.type == 'rare':
                x,y = 947,80
                damagetext = choosefont(25).render('{:.1f} damage'.format(tower.damage),True,(0,0,0))
                speedtext = choosefont(25).render('{}s'.format(tower.speed/1000),True,(0,0,0))
                costtext = choosefont(25).render('{}$'.format(tower.cost),True,(0,0,0))
            elif tower.type == 'epic':
                x,y = 1078,80
                damagetext = choosefont(25).render('{:.1f} damage'.format(tower.damage),True,(0,0,0))
                speedtext = choosefont(25).render('{}s'.format(tower.speed/1000),True,(0,0,0))
                costtext = choosefont(25).render('{}$'.format(tower.cost),True,(0,0,0))
            elif tower.type == 'slow':
                x,y = 816,281
                damagetext = choosefont(25).render(r'{}% slow'.format(int((1-tower.slownum)*100)),True,(0,0,0))
                costtext = choosefont(25).render('{}$'.format(tower.cost),True,(0,0,0))
                speedtext = choosefont(25).render('',True,(0,0,0))
            elif tower.type == 'percent':
                x,y = 947,281
                damagetext = choosefont(25).render(r'{}% damage'.format(int((1-tower.perdamage)*100)),True,(0,0,0))
                speedtext = choosefont(25).render('{}s'.format(tower.speed/1000),True,(0,0,0))
                costtext = choosefont(25).render('{}$'.format(tower.cost),True,(0,0,0))
                maxmin = choosefont(20).render('max:{}  min:{}'.format(tower.maxdamage,tower.mindamage),True,(0,0,0))
                screen.blit(maxmin,((126-maxmin.get_width())/2+x,y+90))

            typetext = choosefont(30).render(tower.type,True,(0,0,0))
            screen.blit(typetext,((126-typetext.get_width())/2+x,y))
            screen.blit(damagetext,((126-damagetext.get_width())/2+x,y+50))
            screen.blit(speedtext,((126-speedtext.get_width())/2+x,y+70))
            screen.blit(costtext,((126-costtext.get_width())/2+x,y+30))


        
        for tower in towers:
            tower.draw(player)
            tower.attack(enemies)
            

        for enemy in enemies:
            enemy.move()
            enemy.draw()
            enemy.hpbar()
            enemy.isarrive()
            enemy.hpcolor()
            player.hpminus(enemy)

            if enemy.health<=0 and enemy.x<=780 and enemy.health>-10000:
                player.score += enemy.initial_hp//10
                player.addmoney(enemy)


        enemyspawn = ((Enemy.num)**0.2)/500+0.03

        if random.random() < enemyspawn:  # 랜덤 모듈로 생성한 난수가 enemyspawn보다 작을때 적 생성
            Enemy.numplus()
            if Enemy.num %40 == 0:# 적 40마리 생성될때 마다 보스 몹 소환
                enemies.append(Enemy(0,100,1000+70*(2**Enemy.bosscount),2,min(6000,Enemy.bosscount*500),'boss'))#적이 생성된 횟수가 많을 수록 체력이 많아짐 --> 점점 난이도 상승
                Enemy.bosscount += 1
            else:#평상시엔 평범한 몹
                enemies.append(Enemy(0, 100,int(300+10*((Enemy.num*10)**0.5)) ,4, min(2000,200+40*(Enemy.num//40)),'common'))#적이 생성된 횟수가 많을 수록 체력이 많아짐 --> 점점 난이도 상승

        # 적이 죽으면 리스트에서 제거
        enemies = [enemy for enemy in enemies if enemy.health > 0]

        spawnp = choosefont(30).render('spawn probability : ' +f'{enemyspawn:.3f}',True,(0,0,0))
        screen.blit(spawnp,(830,730))
        enemyhp = choosefont(30).render(f'common hp : {int(300+10*((Enemy.num*10)**0.5))}',True,(0,0,0))
        screen.blit(enemyhp,(830,755))
        bossenemyhp = choosefont(30).render(f'next boss hp : {1000+70*(2**Enemy.bosscount)-70}',True,(0,0,0))
        screen.blit(bossenemyhp,(830,780))


        if game_over:
            gameover_screen = pygame.Surface((1210, 800), pygame.SRCALPHA)#반투명한 회색으로 화면 채우기
            gameover_screen.fill((128, 128, 128, 200))
            screen.blit(gameover_screen, (0, 0))
            
            gameover_text = choosefont(80).render("Game Over", True, (255, 0, 0))#게임 오버 텍스트
            screen.blit(gameover_text, ((1210-gameover_text.get_width())/2,(800-gameover_text.get_height())/2-90))
            
            score_text = choosefont(50).render(f"SCORE : {player.score}      BESTSCORE : {best_score}", True, (255, 255, 255))#점수 띄우기
            screen.blit(score_text, ((1210-score_text.get_width())/2,(800-score_text.get_height())/2-30))

            restart_text = choosefont(30).render("Press R to restart", True, (255, 255, 255))#다시시작 텍스트
            screen.blit(restart_text, ((1210-restart_text.get_width())/2,(800-restart_text.get_height())/2+10))
            
            pygame.display.update()#이 조건문 이후에 while문에 갇히므로 디스플레이 업데이트 한번하기
            
            while game_over:#게임 정지
                for event in pygame.event.get():
                    if event.type == pygame.QUIT:
                        running = False
                        game_over = False

                    key = pygame.key.get_pressed()
                    if key[pygame.K_r]:#r 누르면 전부 초기화 최고 기록 빼고
                        game_over = False
                        infotowers = [Tower(2000,0,'common'),Tower(2000,0,'rare'),Tower(2000,0,'epic'),Tower(2000,0,'slow'),Tower(2000,0,'percent')]
                        towers = []
                        enemies = []

                        player = Player(10, 4000)
                        tower_type = 'common'
                        Enemy.num = 0
                        Enemy.bosscount = 0

        pygame.display.update()
        clock.tick(60)

    pygame.quit()

# 게임 시작
game_loop()